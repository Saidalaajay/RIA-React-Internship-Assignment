import ArtworksTable from './components/ArtworksTable';

function App() {
  return (
    <div className="App">
      <ArtworksTable />
    </div>
  );
}

export default App;
