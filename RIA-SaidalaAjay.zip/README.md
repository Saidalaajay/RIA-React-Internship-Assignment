# RIA - React Interactive Art

A web-based artwork data viewer using React and PrimeReact DataTable.

## Features
- Server-side pagination
- Custom filtering
- Persistent row selection

## Technologies Used
- React + TypeScript
- Vite
- PrimeReact

## Developer
Saidala Ajay

---
This project was developed as a React assignment to showcase interactive data tables.
